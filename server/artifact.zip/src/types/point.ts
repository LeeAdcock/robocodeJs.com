export default interface Point {
  x: number
  y: number
}
