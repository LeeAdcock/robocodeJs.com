
export default class Clock {
  time: number = 0
}
