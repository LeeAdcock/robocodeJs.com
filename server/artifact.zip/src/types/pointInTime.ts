import Point from './point'

export default interface PointInTime extends Point {
    time: number
}
